<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package varsity
 */
get_header();
$opt    = get_option('varsity_opt');
$blog_single_bg   = isset( $opt['blog_sisngle_header_bg']['url'] ) ? $opt['blog_sisngle_header_bg']['url'] : '';
$is_category_show = isset( $opt['is_category_show']) ? $opt['is_category_show']: '1';
$is_social_share  = isset( $opt['is_social_share']) ? $opt['is_social_share']: '1';
$is_post_tag      = isset( $opt['is_post_tag']) ? $opt['is_post_tag']: '1';
?>
<?php while ( have_posts() ) : the_post(); ?>
<!-- breadcrumb part -->
    <section class="breadcrumb_part blog_breadcrumb" <?php if(!empty($blog_single_bg)): ?> style="background-image: url('<?php echo esc_url($blog_single_bg); ?>')" <?php endif; ?>>
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="breadcrumb_iner">
                        <?php if($is_category_show == '1'): ?>
                        <?php foreach (get_categories() as $category){
                        if ($category->count > 0){
                        echo '<span> '.$category->cat_name.'</span>';
                        } } 
                        ?>
                        <?php endif; ?>
                        <h2><?php the_title(); ?></h2>
                        <div class="breadcrumb_post_author">
                            <p><i class="icon_profile"></i><?php echo get_the_author(); ?></p>
                            <p><i class="icon_clock_alt"></i><?php echo get_the_date(); ?></p>
                            <p><i class="icon_chat_alt"></i><?php varsity_comment_count( get_the_ID(), '' ) ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb part end -->
 <section class="blog_page section_padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="single_blog_details">
                    <div class="blog_details_content">
                        <?php
                         if( has_post_thumbnail() ) : 
                         the_post_thumbnail( 'varsity_blog_770x420', array( 'class' => 'img-fluid' ) );
                         endif;
                        ?>
                        <h2><?php the_title(); ?></h2>
                        <p><?php the_content(); ?></p>
                    </div>                 
                    <div class="tag_share_list blog_page_single_item">
                        <?php if($is_post_tag == '1'): ?>
                        <?php if(has_tag() ): ?>
                        <?php echo educations_tags(); ?>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php if($is_social_share == '1'): ?>
                        <div class="share_icon_list d-flex align-items-center">
                            <h4>Share:</h4>
                            <a href="#"><i class="social_facebook"></i></a>
                            <a href="#"><i class="social_twitter"></i></a>
                            <a href="#"><i class="social_pinterest"></i></a>
                            <a href="#"><i class="social_linkedin"></i></a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php
                       if(get_the_author_meta('description')) {
                       varsity_post_author_metabox();
                       } 
                    ?>
                    <?php
                     // If comments are open or we have at least one comment, load up the comment template.
                      if ( comments_open() || get_comments_number() ) :
                        comments_template();
                      endif;
                    ?>
                </div>
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</section>
<?php endwhile; ?>
<?php
get_footer();
