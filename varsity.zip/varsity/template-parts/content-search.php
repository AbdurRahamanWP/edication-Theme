<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package varsity
 */

?>

<div class="single_page_blog_post">
	<?php 
	 if(has_post_thumbnail()):
       varsity_post_thumbnail();
	 endif; 
	?>
    <div class="single_blog_content">
        <div class="post_author">
            <p><i class="icon_profile"></i><?php echo get_the_author(); ?></p>
            <p><i class="icon_clock_alt"></i><?php echo get_the_Date(); ?></p>
        </div>
        <h2> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
        <p><?php echo  wp_trim_words( get_the_content(), 35, false ); ?></p>
        <a href="<?php the_permalink(); ?>" class="read_more_btn"> <?php echo esc_html__( 'Read More', 'varsity' ); ?><i class="arrow_right"></i> </a>
    </div>
</div>