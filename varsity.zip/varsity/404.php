<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package varsity
 */
$opt = get_option('varsity_opt'); 
$error_logo    = isset( $opt['error_logo']['url'] ) ? $opt['error_logo']['url'] : '';
$error_title = isset( $opt['error_title'] ) ? $opt['error_title'] : '';
$placeholder = isset( $opt['404_placeholder'] ) ? $opt['404_placeholder'] : '';
$btn_label   = isset( $opt['error_home_btn_label'] ) ? $opt['error_home_btn_label'] : '';
get_header();
?>
	 <section class="error_page"  id="scene">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="error_page_iner">
                        <img src="<?php echo esc_url($error_logo); ?>" alt="#" class="img-fluid">
                        <h3><?php echo wp_kses_post($error_title); ?></h3>
                        <form action="#" class="subscribe_form">
                            <input type="email" placeholder="<?php echo wp_kses_post($placeholder); ?>">
                            <a href="#"><i class="arrow_right"></i></a>
                        </form>
                        <p><a href="<?php echo get_site_url(); ?>" class="go_back"><i class="arrow_back"></i><?php echo wp_kses_post($btn_label); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="icon_animation">
            <div class="error_icon_1 scene">
                <div class=" layer" data-depth="0.2">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_1.png" alt="#">
                </div>
            </div>
            <div class="error_icon_2 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_2.png" alt="#">
                </div>
            </div>
            <div class="error_icon_3 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_3.png" alt="#">
                </div>
            </div>
            <div class="error_icon_4 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_4.png" alt="#">
                </div>
            </div>
            <div class="error_icon_5 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_5.png" alt="#">
                </div>
            </div>
            <div class="error_icon_6 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_7.png" alt="#">
                </div>
            </div>
            <div class="error_icon_7 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_6.png" alt="#">
                </div>
            </div>
            <div class="error_icon_8 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_9.png" alt="#">
                </div>
            </div>
            <div class="error_icon_9 scene">
                <div class=" layer" data-depth="0.1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error/icon_8.png" alt="#">
                </div>
            </div>
        </div>
    </section>
<?php
get_footer();
