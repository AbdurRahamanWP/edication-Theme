<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package varsity
 */
/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>
<div class="single_review_part blog_page_single_item">
<?php
$is_comments = have_comments() ? 'have_comments' : 'no_comments';
if( have_comments() ) {
	?>
    <div class="comment_part wow fadeInUp <?php echo esc_attr( $is_comments ); ?>">
        <h3> <?php varsity_comment_count( get_the_ID(), '' ) ?> </h3>
        <div class="comment_reply_form">
            <ul class="comment-list">
				<?php
				wp_list_comments(
					array(
						'style'      => 'ul',
						'short_ping' => true,
						'callback'   => 'varsity_comments'
					),
					get_comments( array(
						'post_id' => get_the_ID(),
					) )
				);
				the_comments_navigation();
				?>
            </ul>
        </div>
    </div>
	<?php
} ?>
</div>
<?php
    $commenter      = wp_get_current_commenter();
    $req            = get_option( 'require_name_email' );
    $aria_req       = ( $req ? " aria-required='true'" : '' );
    $fields =  array(
        'author'=> '<div class="col-lg-6 form_single_item"><input type="text" name="author" class="form-control" value="'.esc_attr($commenter['comment_author']).'" placeholder="'.esc_attr__('Name *', 'varsity').'" '.$aria_req.'></div>',
        'email'	=> '<div class="col-lg-6 form_single_item"><input type="email" class="form-control" name="email" id="email" placeholder="'.esc_attr__('Email *', 'varsity').'" '.$aria_req.'></div>',
        'cookies' => ''
    );
    $comments_args = array(
        'fields'                => apply_filters( 'comment_form_default_fields', $fields ),
        'class_form'            => 'review_form blog_page_single_item row',
        'id_form'               => 'form_single_item',
        'submit_button'         => '<input type="submit" name="%1$s"  id="%2$s" class="btn_3" value="Submit Review">',
        'title_reply_before'    => '<div class="blog_page_single_item mb-0"><h3 class="mb-4">',
        'title_reply'           => esc_html__('Leave a Reply', 'varsity'),
        'title_reply_after'     => '</h3></div>',
        'comment_notes_before'  => '',
        'comment_field'         => '<div class="col-lg-12 form_single_item"><textarea class="form-control" name="comment" placeholder="'. esc_attr__( 'Review Content...', 'varsity' ) .'" required></textarea></div>',
        'comment_notes_after'   => '',
    );
    comment_form($comments_args);
?>