<?php

/**
 * Register Google fonts.
 *
 * @return string Google fonts URL for the theme.
 */
function varsity_fonts_url() {
    $fonts_url = '';
    $fonts     = array();
    $subsets   = '';

    /* Body font */
    if ( 'off' !== 'on' ) {
        $fonts[] = "Poppins:300,400,500,600,700";
    }

    $is_ssl = is_ssl() ? 'https' : 'http';

    if ( $fonts ) {
        $fonts_url = add_query_arg( array(
            'family' => urlencode( implode( '|', $fonts ) ),
            'subset' => urlencode( $subsets ),
        ), "$is_ssl://fonts.googleapis.com/css" );
    }

    return $fonts_url;
}

function varsity_enque_scripts() {
    wp_enqueue_style( 'varsity-style', get_stylesheet_uri() );
    wp_enqueue_style('bootstrap',  VARSITY_DIR_CSS.'/bootstrap.min.css');
    wp_enqueue_style('animate',  VARSITY_DIR_CSS.'/animate.css');
    wp_enqueue_style('elegent_icon',  VARSITY_DIR_VEND.'/elegant_Icon/elegent_icon.css');
    wp_enqueue_style('nice-select',  VARSITY_DIR_VEND.'/niceselect/css/nice-select.css');
    wp_enqueue_style('carousel',  VARSITY_DIR_VEND.'/owl_carousel/css/owl.carousel.css');
    wp_enqueue_style('magnific',  VARSITY_DIR_VEND.'/magnify_popup/magnific-popup.css');
    wp_enqueue_style('Countdown',  VARSITY_DIR_VEND.'/countdown/css/Countdown.css');
    wp_enqueue_style('flaticon',  VARSITY_DIR_CSS.'/flaticon.css');
    wp_enqueue_style('aos',  VARSITY_DIR_VEND.'/aos/aos.css');
    wp_enqueue_style('style',  VARSITY_DIR_CSS.'/style.css');
    
  // js Style

    wp_enqueue_script( 'jquery-min', VARSITY_DIR_JS.'/jquery-3.4.1.min.js', array('jquery'), '3.4.1', true );
    wp_enqueue_script( 'popper-min', VARSITY_DIR_JS.'/popper.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'bootstrap-min', VARSITY_DIR_JS.'/bootstrap.min.js', array('jquery'), '4.4.1', true );
    wp_enqueue_script( 'nice-select', VARSITY_DIR_VEND.'/niceselect/js/jquery.nice-select.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'carousel-min', VARSITY_DIR_VEND.'/owl_carousel/js/owl.carousel.min.js', array('jquery'), '2.3.4', true );
    wp_enqueue_script( 'magnific-popup', VARSITY_DIR_VEND.'/magnify_popup/jquery.magnific-popup.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'simplyCountdown', VARSITY_DIR_VEND.'/countdown/js/simplyCountdown.min.js', array('jquery'), '1.5.0', true );
    wp_enqueue_script( 'countTo', VARSITY_DIR_VEND.'/counter/jquery.countTo.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'aos-js', VARSITY_DIR_VEND.'/aos/aos.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'custom', VARSITY_DIR_JS.'/custom.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'comming-soon', VARSITY_DIR_JS.'/comming-soon.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'gmap', VARSITY_DIR_VEND.'/gmp3/map.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'google_js', 'https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyDs3mrTgrYd6_hJS50x4Sha1lPtS2T-_JA', '5.3.2', true );

    
}
add_action( 'wp_enqueue_scripts', 'varsity_enque_scripts' );