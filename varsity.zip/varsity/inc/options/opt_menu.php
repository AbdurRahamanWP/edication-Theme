<?php
// Navbar styling
Redux::setSection('varsity_opt', array(
    'title'            => esc_html__( 'Menu Settings', 'varsity' ),
    'id'               => 'menu_opt',
    'icon'             => 'el el-lines',
    'fields'           => array(
        array(
            'id'            => 'menu_typo',
            'type'          => 'typography',
            'title'         => esc_html__( 'Menu Typography', 'varsity'),
            'subtitle'      => esc_html__( 'Menu item typography options', 'varsity'),
            'color'         => false,
            'output'        => '.navbar_bar ul li a'
        ),
        array(
            'title'     => esc_html__('Menu Item Color', 'varsity'),
            'subtitle'  => esc_html__('Menu item font color', 'varsity'),
            'id'        => 'menu_font_color',
            'output'    => '.navbar_bar ul li a',
            'type'      => 'color',
        ),
        array(
            'title'     => esc_html__('Menu Active Color', 'varsity'),
            'subtitle'  => esc_html__('Menu item active and hover font color', 'varsity'),
            'id'        => 'menu_active_font_color',
            'output'    => array(
                'background' => '.navbar_bar ul li a:hover::before',
            ),
            'type'      => 'color',
        ),
        array(
            'title'     => esc_html__('Menu item margin', 'varsity'),
            'subtitle'  => esc_html__('Margin around menu item.', 'varsity'),
            'id'        => 'menu_item_margin',
            'type'      => 'spacing',
            'output'    => array( '.navbar_bar ul li a' ),
            'mode'      => 'margin',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
        ),
        // Sticky menu settings section
        array(
            'id' => 'sticky_menu_start',
            'type' => 'section',
            'title' => esc_html__('Sticky menu settings', 'varsity'),
            'subtitle' => esc_html__('The following settings will only apply on the sticky header mode..', 'varsity'),
            'indent' => true
        ),
        array(
            'title'     => esc_html__('Menu Color', 'varsity'),
            'subtitle'  => esc_html__('Menu item font color on sticky menu mode.', 'varsity'),
            'id'        => 'sticky_menu_font_color',
            'output'    => '.navbar_bar ul li a',
            'type'      => 'color',
        ),
        array(
            'title'     => esc_html__('Menu Active Color', 'varsity'),
            'subtitle'  => esc_html__('Menu item active font color on header sticky mode', 'varsity'),
            'id'        => 'menu_sticky_active_font_color',
            'output'    => array(
                'color' => '
                    .navbar_bar ul li a.nav-link:hover::before,
                ',
            ),
            'type'      => 'color',
        ),
        array(
            'id'     => 'sticky_menu_end',
            'type'   => 'section',
            'indent' => false,
        ),
    )
));