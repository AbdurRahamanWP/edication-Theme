<?php
// Footer settings
Redux::setSection('varsity_opt', array(
	'title'     => esc_html__('Footer Settings', 'varsity'),
	'id'        => 'varsity_footer',
	'icon'      => 'el el-arrow-down',
    'fields'           => array(
        array(
            'title'     => esc_html__('Footer Widget', 'varsity'),
            'description'=> esc_html__('Switch to Hide if want to hide the Footer Widget', 'varsity' ),
		    'id'        => 'if_footer_widget',
		    'type'      => 'switch',
		    'on'        => esc_html__('Show', 'varsity'),
		    'off'       => esc_html__('Hide', 'varsity'),
		    'default'   => '1'
	    ),
        array(
            'title'     => esc_html__('Section Background Color', 'varsity'),
            'desc'      => esc_html__('Footer Widget Section background Color', 'varsity'),
            'id'        => 'footer_widget_bg_color',
            'type'      => 'color',
            'mode'      => 'background',
            'output'    => array( '.footer_section' )
        ),
        array(
            'title'     => esc_html__('Font color', 'varsity'),
            'desc'      => esc_html__('Footer Widget Section Font Color', 'varsity'),
            'id'        => 'footer_top_font_color',
            'type'      => 'color',
            'output'    => array('.footer_section .footer_nav h4, .footer_section .footer_nav p')
        ),
        array(
            'title'     => esc_html__('Typography Settings', 'varsity'),
            'desc'      => esc_html__('The Footer Widget Typography Settings', 'varsity'),
            'id'        => 'topbar_typography',
             'type'     => 'typography',
            'color'     => false,
            'output'    => '.footer_section',
        ),
    )
));
// Footer settings
Redux::setSection('varsity_opt', array(
    'title'     => esc_html__('Footer Bottom', 'varsity'),
    'id'        => 'varsity_footer_btm',
    'icon'      => 'el el-lines',
    'subsection'=> true,
    'fields'    => array(
        array(
            'title'     => esc_html__('Footer Social Icon', 'varsity'),
            'description'=> esc_html__('Switch to Hide if want to hide the Social Icon.', 'varsity' ),
            'id'        => 'footer_social_icon',
            'type'      => 'switch',
            'on'        => esc_html__('Show', 'varsity'),
            'off'       => esc_html__('Hide', 'varsity'),
            'default'   => '1'
        ),
        array(
            'title'     => esc_html__('Copyright Content', 'varsity'),
            'id'        => 'copyright_txt',
            'type'      => 'editor',
            'default'   => '© 2020 <a href="//droitthemes.com">DroiThemes</a>. All rights reserved',
            'args'    => array(
                'wpautop'       => true,
                'media_buttons' => false,
                'textarea_rows' => 10,
                //'tabindex' => 1,
                //'editor_css' => '',
                'teeny'         => false,
                //'tinymce' => array(),
                'quicktags'     => false,
            )
        ),
    )
));

// Footer settings
Redux::setSection('varsity_opt', array(
    'title'     => esc_html__('Footer Shape', 'varsity'),
    'id'        => 'varsity_footer_shape',
    'icon'      => 'el el-lines',
    'subsection'=> true,
    'fields'    => array(
        array(
            'title'     => esc_html__('Footer Shape', 'varsity'),
            'description'=> esc_html__('Switch to Hide if want to hide the Footer Shape Images.', 'varsity' ),
            'id'        => 'footer_shape_images',
            'type'      => 'switch',
            'on'        => esc_html__('Show', 'varsity'),
            'off'       => esc_html__('Hide', 'varsity'),
            'default'   => '1'
        ),
        array(
            'title'     => esc_html__('Shape One', 'varsity'),
            'subtitle'  => esc_html__( 'Upload here a image file for Footer Shape One Images', 'varsity' ),
            'id'        => 'shape_one',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/icon/shape_01.png'
            )
        ),
        array(
            'title'     => esc_html__('Shape Two', 'varsity'),
            'subtitle'  => esc_html__( 'Upload here a image file for Footer Shape Two Images', 'varsity' ),
            'id'        => 'shape_two',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/icon/about_shape_02.png'
            )
        ),
        array(
            'title'     => esc_html__('Shape Three', 'varsity'),
            'subtitle'  => esc_html__( 'Upload here a image file for Footer Shape Three Images', 'varsity' ),
            'id'        => 'shape_three',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/icon/about_shape_03.png'
            )
        ) 
    )
));
// Footer settings
Redux::setSection('varsity_opt', array(
    'title'     => esc_html__('Footer C2A', 'varsity'),
    'id'        => 'varsity_footer_calltoaction',
    'icon'      => 'el el-lines',
    'subsection'=> true,
    'fields'    => array(
        array(
            'title'     => esc_html__('Title Text', 'varsity'),
            'subtitle'  => esc_html__('Give here the C2A title', 'varsity'),
            'id'        => 'c2t_title',
            'type'      => 'text',
            'default'   => esc_html__('Best teachers in every subject. <br>Let’s get started', 'varsity')
        ),
        array(
            'title'     => esc_html__('Sub Title Text', 'varsity'),
            'subtitle'  => esc_html__('Give here the C2A Sub title', 'varsity'),
            'id'        => 'c2t_sub_title',
            'type'      => 'text',
            'default'   => esc_html__('We can teach you anything', 'varsity')
        ),
        array(
            'title'     => esc_html__('Button Level', 'varsity'),
            'subtitle'  => esc_html__('Give here the C2A Button Level', 'varsity'),
            'id'        => 'c2t_button_text',
            'type'      => 'text',
            'default'   => esc_html__('Get Started', 'varsity')
        ),
        array(
            'title'     => esc_html__('Button Url', 'varsity'),
            'subtitle'  => esc_html__('Give here the C2A Button Level', 'varsity'),
            'id'        => 'c2t_button_url',
            'type'      => 'text',
            'default'   => esc_html__('#', 'varsity')
        ),
    )
));