<?php
Redux::setSection('varsity_opt', array(
	'title'     => esc_html__('Blog settings', 'varsity'),
	'id'        => 'blog_page',
	'icon'      => 'dashicons dashicons-admin-post',
));
Redux::setSection('varsity_opt', array(
	'title'     => esc_html__('Blog Page', 'varsity'),
	'id'        => 'blog_titlebar_settings',
	'icon'      => 'dashicons dashicons-admin-post',
    'subsection' => true,
	'fields'    => array(
		array(
			'title'     => esc_html__('Blog page title', 'varsity'),
			'subtitle'  => esc_html__('Give here the blog page title', 'varsity'),
			'desc'      => esc_html__('This text will be show on blog page banner', 'varsity'),
			'id'        => 'blog_title',
			'type'      => 'text',
			'default'   => esc_html__('Blog Classic', 'varsity')
		),
        array(
            'title'         => esc_html__('Title font properties', 'varsity'),
            'id'            => 'blog_titlebar_title_typo',
            'type'          => 'typography',
            'google'        => true,
            'text-align'    => true,
            'output'        => '.blog_grid_bg .breadcrumb_part h2',
            'preview'       => array(
                'always_display' => false
            )
        ),
        array(
            'title'     => esc_html__('Background Color', 'varsity'),
            'id'        => 'blog_banner_bg_color',
            'output'    => '.blog_grid_bg',
            'type'      => 'color',
            'mode'      => 'background'
        ),
        array(
            'title'     => esc_html__('Background Images', 'varsity'),
            'subtitle'  => esc_html__( 'Upload here a image file for Blog Header Background Images', 'varsity' ),
            'id'        => 'blog_header_bg',
            'type'      => 'media'
        ),
        array(
			'title'     => esc_html__('Call Two Action Button', 'varsity'),
			'subtitle'  => esc_html__('Show/hide C2A Button on blog page', 'varsity'),
			'id'        => 'is_blog_c2a',
			'type'      => 'switch',
            'on'        => esc_html__('Show', 'varsity'),
            'off'       => esc_html__('Hide', 'varsity'),
            'default'   => '1',
		),

	)
));
Redux::setSection('varsity_opt', array(
	'title'     => esc_html__('Blog single', 'varsity'),
	'id'        => 'blog_single_opt',
	'icon'      => 'dashicons dashicons-info',
	'subsection' => true,
	'fields'    => array(
		array(
			'title'     => esc_html__('Category Display', 'varsity'),
			'description'=> esc_html__('Switch to Hide if want to hide the Category in Header Section', 'varsity' ),
			'id'        => 'is_category_show',
			'type'      => 'switch',
            'on'        => esc_html__('Enabled', 'varsity'),
            'off'       => esc_html__('Disabled', 'varsity'),
            'default'   => '1'
		),
		array(
			'title'     => esc_html__('Social share', 'varsity'),
			'description'=> esc_html__('Switch to Hide if want to hide the Social Share in Post', 'varsity' ),
			'id'        => 'is_social_share',
			'type'      => 'switch',
            'on'        => esc_html__('Enabled', 'varsity'),
            'off'       => esc_html__('Disabled', 'varsity'),
            'default'   => '1'
		),
		array(
			'title'     => esc_html__('Post tag', 'varsity'),
			'description'=> esc_html__('Switch to Hide if want to hide the Post Tags in Post', 'varsity' ),
			'id'        => 'is_post_tag',
			'type'      => 'switch',
            'on'        => esc_html__('Show', 'varsity'),
            'off'       => esc_html__('Hide', 'varsity'),
            'default'   => '1'
		),
		 array(
            'title'     => esc_html__('Header Background Color', 'varsity'),
            'id'        => 'blog_single_bg_color',
            'output'    => '.blog_breadcrumb',
            'type'      => 'color',
            'mode'      => 'background'
        ),
		array(
            'title'     => esc_html__('Header Background Images', 'varsity'),
            'subtitle'  => esc_html__( 'Upload here a image file for Blog Single Header Background Images', 'varsity' ),
            'id'        => 'blog_sisngle_header_bg',
            'type'      => 'media'
        ),
	)
));