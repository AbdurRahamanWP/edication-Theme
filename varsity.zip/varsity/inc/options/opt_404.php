<?php
Redux::setSection('varsity_opt', array(
    'title'     => esc_html__('404 Settings', 'varsity'),
    'id'        => '404_0pt',
    'icon'      => 'dashicons dashicons-info',
    'fields'    => array(
       array(
            'title'     => esc_html__('404 logo', 'varsity'),
            'subtitle'  => esc_html__( 'Upload here a image file for your 404 Page', 'varsity' ),
            'id'        => 'error_logo',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/error.png'
            )
        ),
        array(
            'title'     => esc_html__('Page Title', 'varsity'),
            'id'        => 'error_title',
            'subtitle'  => esc_html__( 'Enter The 404 Page Title', 'varsity' ),
            'type'      => 'text',
            'default'   => esc_html__('We are Sorry, Page not found', 'varsity'),
        ),
        array(
            'title'     => esc_html__('Title Font Color', 'varsity'),
            'desc'      => esc_html__('404 Page Header Font Color', 'varsity'),
            'id'        => '404_page_font_color',
            'type'      => 'color',
            'output'    => array( '.error_page .error_page_iner h3' )
        ),
        array(
            'title'     => esc_html__('Typography Settings', 'varsity'),
            'desc'      => esc_html__('The 404 Page Header Font Typography Settings', 'varsity'),
            'id'        => '404_title_typography',
             'type'     => 'typography',
            'color'     => false,
            'output'    => '.error_page .error_page_iner h3',
        ),
        array(
            'title'     => esc_html__('Subscription Form placeholder Text', 'varsity'),
            'id'        => '404_placeholder',
            'type'      => 'text',
            'default'   => esc_html__('Enter Your Email Address', 'varsity'),  
        ),
        array(
            'title'     => esc_html__('Home button label', 'varsity'),
            'id'        => 'error_home_btn_label',
            'type'      => 'text',
            'default'   => esc_html__('Back to Homepage', 'varsity'),
            
        )
    )
));