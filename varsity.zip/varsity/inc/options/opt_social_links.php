<?php
Redux::setSection('varsity_opt', array(
    'title'     => esc_html__('Social links', 'varsity'),
    'id'        => 'opt_social_links',
    'icon'      => 'dashicons dashicons-share',
    'fields'    => array(
        array(
            'id'    => 'facebook',
            'type'  => 'text',
            'title' => esc_html__('Facebook', 'varsity'),
            'desc' => esc_html__('If You Keep It Blank It Will Not Be Show Social Icon Section', 'varsity'),
            'default'	 => '#'
        ),
        array(
            'id'    => 'twitter',
            'type'  => 'text',
            'title' => esc_html__('Twitter', 'varsity'),
            'desc' => esc_html__('If You Keep It Blank It Will Not Be Show Social Icon Section', 'varsity'),
            'default'	  => '#'
        ),
        array(
            'id'    => 'vimeo',
            'type'  => 'text',
            'title' => esc_html__('Vimeo', 'varsity'),
            'desc' => esc_html__('If You Keep It Blank It Will Not Be Show Social Icon Section', 'varsity'),
            'default'	  => '#'
        ),
        array(
            'id'    => 'linkedin',
            'type'  => 'text',
            'title' => esc_html__('LinkedIn', 'varsity'),
            'desc' => esc_html__('If You Keep It Blank It Will Not Be Show Social Icon Section', 'varsity'),
            'default'	  => '#'
        ),
        array(
            'id'    => 'dribbble',
            'type'  => 'text',
            'title' => esc_html__('Dribbble', 'varsity'),
            'desc' => esc_html__('If You Keep It Blank It Will Not Be Show Social Icon Section', 'varsity'),
            'default'	  => '#'
        ),
        array(
            'id'    => 'youtube',
            'type'  => 'text',
            'title' => esc_html__('Youtube', 'varsity'),
            'desc' => esc_html__('If You Keep It Blank It Will Not Be Show Social Icon Section', 'varsity')
        ),
        array(
            'id'    => 'instagram',
            'type'  => 'text',
            'title' => esc_html__('Instagram', 'varsity'),
            'desc' => esc_html__('If You Keep It Blank It Will Not Be Show Social Icon Section', 'varsity')
        ),
    ),
));