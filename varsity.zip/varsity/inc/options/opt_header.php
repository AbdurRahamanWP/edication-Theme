<?php
// Header Section
Redux::setSection('varsity_opt', array(
    'title'            => esc_html__( 'Header Settings', 'varsity' ),
    'id'               => 'header_sec',
    'customizer_width' => '400px',
    'icon'             => 'el el-arrow-up',
));
// Header Section
Redux::setSection('varsity_opt', array(
    'title'            => esc_html__( 'Header Top Bar', 'varsity' ),
    'id'               => 'header_content_sec',
    'customizer_width' => '400px',
    'icon'             => 'el el-lines',
    'subsection'       => true,
    'fields'           => array(
        array(
            'id'        => 'is_preloader',
            'type'      => 'switch',
            'title'     => esc_html__( 'Preloader Settings', 'varsity' ),
            'on'        => esc_html__('Enable', 'varsity'),
            'off'       => esc_html__('Disable', 'varsity'),
            'default'   => true,
        ),
        array(
            'id'        => 'is_header_topbar',
            'type'      => 'switch',
            'title'     => esc_html__( 'Header Top Bar', 'varsity' ),
            'on'        => esc_html__('Enable', 'varsity'),
            'off'       => esc_html__('Disable', 'varsity'),
            'default'   => true,
        ),
        array(
            'required' => array('is_header_topbar', '=', '1'),
            'id'        => 'contact_no',
            'type'      => 'text',
            'title'     => esc_html__( 'Contact Number', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter Your Contact Number', 'varsity' ),
            'desc'      => esc_html__( 'If you keep this field blank, the "Contact Number" Field will not be shown within the Header Topbar.', 'varsity' ),
            'default'   => esc_html__( '+464 145 684 325', 'varsity' ),
        ),
        array(
            'required' => array('is_header_topbar', '=', '1'),
            'id'        => 'top_email',
            'type'      => 'text',
            'title'     => esc_html__( 'Email Address', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter Your Email Address', 'varsity' ),
            'desc'      => esc_html__( 'If you keep this field blank, the "Email Address" Field will not be shown within the Header Topbar.', 'varsity' ),
            'default'   => esc_html__( 'info@droitthems.com', 'varsity' ),
        ),
        array(
            'required' => array('is_header_topbar', '=', '1'),
            'id'        => 'top_login',
            'type'      => 'text',
            'title'     => esc_html__( 'Login Button', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter Login Buton Text', 'varsity' ),
            'desc'      => esc_html__( 'If you keep this field blank, the "Login Button" Field will not be shown within the Header Topbar.', 'varsity' ),
            'default'   => esc_html__( 'Login', 'varsity' ),
        ),
        array(
            'required' => array('is_header_topbar', '=', '1'),
            'id'        => 'top_login_url',
            'type'      => 'text',
            'title'     => esc_html__( 'Login Button URL', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter Login Buton URL', 'varsity' ),
            'default'   => esc_html__( '#', 'varsity' ),
        ),
        array(
            'required' => array('is_header_topbar', '=', '1'),
            'id'        => 'top_register',
            'type'      => 'text',
            'title'     => esc_html__( 'Register Button', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter Register Buton Text', 'varsity' ),
            'desc'      => esc_html__( 'If you keep this field blank, the "Register Button" Field will not be shown within the Header Topbar.', 'varsity' ),
            'default'   => esc_html__( 'Register', 'varsity' ),
        ),
        array(
            'required' => array('is_header_topbar', '=', '1'),
            'id'        => 'top_register_url',
            'type'      => 'text',
            'title'     => esc_html__( 'Register Button URL', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter Register Buton URL', 'varsity' ),
            'default'   => esc_html__( '#', 'varsity' ),
        ),
        array(
            'title'     => esc_html__('Background Color', 'varsity'),
            'desc'      => esc_html__('The Header Top Bar background Color', 'varsity'),
            'id'        => 'topbar_bgcolor',
            'type'      => 'color',
            'mode'      => 'background',
            'output'    => array( '.section_bg' )
        ),
        array(
            'title'     => esc_html__('Font Color', 'varsity'),
            'desc'      => esc_html__('The Header Top Bar Font Color', 'varsity'),
            'id'        => 'topbar_font_color',
            'type'      => 'color',
            'output'    => array( '.header_part .sub_header a' )
        ),
        array(
            'title'     => esc_html__('Typography Settings', 'varsity'),
            'desc'      => esc_html__('The Header Top Bar Typography Settings', 'varsity'),
            'id'        => 'topbar_typography',
             'type'     => 'typography',
            'color'     => false,
            'output'    => '.header_part .sub_header',
        ),
    )
));
// Logo
Redux::setSection('varsity_opt', array(
    'title'            => esc_html__( 'Logo Settings', 'varsity' ),
    'id'               => 'logo_opt',
    'subsection'       => true,
    'icon'             => 'el el-lines',
    'fields'           => array(
        array(
            'title'     => esc_html__('Upload logo', 'varsity'),
            'subtitle'  => esc_html__( 'Upload here a image file for your logo', 'varsity' ),
            'id'        => 'main_logo',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/logo.png'
            )
        ),
        array(
            'title'     => esc_html__('Sticky header logo', 'varsity'),
            'id'        => 'sticky_logo',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/logo.png'
            )
        ),
        array(
            'title'     => esc_html__('Retina Logo', 'varsity'),
            'subtitle'  => esc_html__('The retina logo should be double (2x) of your original logo', 'varsity'),
            'id'        => 'retina_logo',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/logo@2x.png'
            )
        ),
        array(
            'title'     => esc_html__('Retina Sticky Logo', 'varsity'),
            'subtitle'  => esc_html__('The retina logo should be double (2x) of your original logo', 'varsity'),
            'id'        => 'retina_sticky_logo',
            'type'      => 'media',
            'compiler'  => true,
            'default'   => array(
                'url'   => get_template_directory_uri().'/assets/img/logo@2x.png'
            )
        ),
        array(
            'title'     => esc_html__('Logo dimensions', 'varsity'),
            'subtitle'  => esc_html__( 'Set a custom height width for your upload logo.', 'varsity' ),
            'id'        => 'logo_dimensions',
            'type'      => 'dimensions',
            'units'     => array('em','px','%'),
            'output'    => '.logo>img'
        ),
        array(
            'title'     => esc_html__('Padding', 'varsity'),
            'subtitle'  => esc_html__('Padding around the logo. Input the padding as clockwise (Top Right Bottom Left)', 'varsity'),
            'id'        => 'logo_padding',
            'type'      => 'spacing',
            'output'    => array( '.logo' ),
            'mode'      => 'padding',
            'units'     => array( 'em', 'px', '%' ),      // You can specify a unit value. Possible: px, em, %
            'units_extended' => 'true',
        ),
    )
) );
// Button Section
Redux::setSection('varsity_opt', array(
    'title'            => esc_html__( 'Menu Button', 'varsity' ),
    'id'               => 'menu_get_start_button',
    'customizer_width' => '400px',
    'icon'             => 'el el-lines',
    'subsection'       => true,
    'fields'           => array(
        array(
            'id'        => 'is_menu_button',
            'type'      => 'switch',
            'title'     => esc_html__( 'Get Started Button', 'varsity' ),
            'subtitle'  => esc_html__( 'Switch to Disable if want to hide the Get Started Button.', 'varsity' ),
            'on'        => esc_html__('Enable', 'varsity'),
            'off'       => esc_html__('Disable', 'varsity'),
            'default'   => true,
        ),
        array(
            'required' => array('is_menu_button', '=', '1'),
            'id'        => 'get_started',
            'type'      => 'text',
            'title'     => esc_html__( 'Button Text', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter The Button Text', 'varsity' ),
            'default'   => esc_html__( 'Get Started', 'varsity' ),
        ),
        array(
            'required' => array('is_menu_button', '=', '1'),
            'id'        => 'get_started_url',
            'type'      => 'text',
            'title'     => esc_html__( 'Button URL', 'varsity' ),
            'subtitle'  => esc_html__( 'Enter Buton URL', 'varsity' ),
            'default'   => esc_html__( '#', 'varsity' ),
        ),
        array(
            'required' => array('is_menu_button', '=', '1'),
            'title'     => esc_html__('Background Color', 'varsity'),
            'desc'      => esc_html__('The Header Top Bar background Color', 'varsity'),
            'id'        => 'topbar_bgcolor',
            'type'      => 'color',
            'mode'      => 'background',
            'output'    => array( '.btn_1' )
        ),
        array(
            'required' => array('is_menu_button', '=', '1'),
            'title'     => esc_html__('Font Color', 'varsity'),
            'desc'      => esc_html__('The Header Top Bar Font Color', 'varsity'),
            'id'        => 'topbar_font_color',
            'type'      => 'color',
            'output'    => array( '.btn_1' )
        ),
        array(
            'required' => array('is_menu_button', '=', '1'),
            'title'     => esc_html__('Typography Settings', 'varsity'),
            'desc'      => esc_html__('The Menu Right Button Typography Settings', 'varsity'),
            'id'        => 'topbar_typography',
             'type'     => 'typography',
            'color'     => false,
            'output'    => '.btn_1',
        ),
    )
));