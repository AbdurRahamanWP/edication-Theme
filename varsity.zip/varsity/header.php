<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package varsity
 */
$opt = get_option('varsity_opt'); 
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<?php 
$is_preloader     = isset( $opt['is_preloader'] ) ? $opt['is_preloader'] : '0';
$is_header_topbar = isset( $opt['is_header_topbar'] ) ? $opt['is_header_topbar'] : '0';
$contact_no      = isset( $opt['contact_no'] ) ? $opt['contact_no'] : '';
$emailid         = isset( $opt['top_email'] ) ? $opt['top_email'] : '';
$login_button    = isset( $opt['top_login'] ) ? $opt['top_login'] : '';
$login_url       = isset( $opt['top_login_url'] ) ? $opt['top_login_url'] : '';
$register_button = isset( $opt['top_register'] ) ? $opt['top_register'] : '';
$register_url    = isset( $opt['top_register_url'] ) ? $opt['top_register_url'] : '';
$main_logo       = isset( $opt['main_logo']['url'] ) ? $opt['main_logo']['url'] : '';
$sticky_logo     = isset( $opt['sticky_logo']['url'] ) ? $opt['sticky_logo']['url'] : '';
$retina_logo     = isset( $opt['retina_logo']['url'] ) ? $opt['retina_logo']['url'] : '';
$retina_sticky   = isset( $opt['retina_sticky_logo']['url'] ) ? $opt['retina_sticky_logo']['url'] : '';
$logo_srcset     = !empty($retina_logo) ?  "srcset='$retina_logo 2x'" : '';
$logo_srcset_sticky = !empty($retina_sticky) ?  "srcset='$retina_sticky 2x'" : '';
$is_menu_button  = isset( $opt['is_menu_button'] ) ? $opt['is_menu_button'] : '';
$get_started     = isset( $opt['get_started'] ) ? $opt['get_started'] : '';
$get_started_url = isset( $opt['get_started_url'] ) ? $opt['get_started_url'] : '';
$blog_header     = is_home() || is_singular('post') ? 'single_page_header' : '';
?>
<body <?php body_class(); ?>>
<!-- start Preloader  -->
    <?php if($is_preloader == '1'): ?>
    <div class="preloder_part">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>
   <?php endif; ?>
    <!-- End Preloader  -->
   <header class="header_part <?php echo esc_attr($blog_header); ?>">
        <?php if($is_header_topbar == '1'): ?>
   		<div class="sub_header section_bg">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-7 col-md-8">
                        <div class="header_contact_info">
                            <?php if(!empty($contact_no)) : ?>
                            <a href="tel:<?php echo wp_kses_post($contact_no); ?>"><i class="icon_phone"></i><?php echo wp_kses_post($contact_no); ?></a>
                            <?php endif; ?>
                            <?php if($emailid): ?>
                            <a href="mailto:<?php echo wp_kses_post($emailid); ?>" target="_blank"><i class="icon_mail_alt"></i><?php echo wp_kses_post($emailid); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-5 col-md-4">
                        <div class="header_login_info">
                            <?php if(!empty($login_button)) : ?>
                            <a href="<?php echo esc_url($login_url); ?>"><?php echo wp_kses_post($login_button); ?></a>
                            <?php  endif; ?>
                            <?php if(!empty($register_button)): ?>
                            <a href="<?php echo esc_url($register_url); ?>"><?php echo wp_kses_post($register_button); ?></a>
                           <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="main_nav">
           <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header_iner d-flex justify-content-between align-items-center">
                            <div class="sidebar_icon troggle_icon d-lg-none">
                                <i class="icon_menu"></i>
                            </div>
                            <div class="logo">
                                <?php if(!empty($main_logo)): ?>
                                <a href="<?php echo home_url() ?>" class="main_logo"><img src="<?php echo esc_url($main_logo); ?>" srcset="<?php echo wp_kses_post($logo_srcset); ?>" alt="<?php echo get_bloginfo(); ?>"></a>
                                <?php endif; ?>
                                <?php if(!empty($sticky_logo)): ?>
                                <a href="<?php echo home_url() ?>" class="sticky_logo"><img src="<?php echo esc_url($sticky_logo); ?>" srcset="<?php echo wp_kses_post($logo_srcset_sticky); ?>" alt="<?php echo get_bloginfo(); ?>"></a>
                                <?php endif; ?>
                            </div>
                            <nav class="navbar_bar">
                                <?php
                                 if ( has_nav_menu('main_menu') ) {
                                    wp_nav_menu(array(
                                        'menu' => 'main_menu',
                                        'theme_location' => 'main_menu',
                                        'menu_class' => 'navbar_bar',
                                        'container' => 'ul',
                                        'depth' => 3,
                                        'walker' => new varsity_Nav_Navwalker()
                                    ));
                                  }  
                                ?>
                            </nav>
                            <?php
                             if(!empty($is_menu_button)):
                            ?>
                            <div class="navbar_btn">
                                <a href="<?php echo esc_url($get_started_url); ?>" class="btn_1"><?php echo wp_kses_post($get_started); ?></a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </header>
    <?php 
    $page_header = function_exists( 'get_field' ) ? get_field( 'page_header' ) : '';
    $header_background_images = function_exists('get_field') ? get_field('header_background_images') : '';
    if($page_header == '1'):
    ?>
    <section class="breadcrumb_part parallax_background" <?php if(!empty($header_background_images)): ?> style="background-image: url(<?php echo esc_url($header_background_images['url']); ?>);"  <?php endif; ?> >
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="breadcrumb_iner">
                        <h2><?php the_title(); ?></h2>
                        <?php varsity_breadcrumbs();  ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php 
     endif;
    ?>
    <!-- header part end -->