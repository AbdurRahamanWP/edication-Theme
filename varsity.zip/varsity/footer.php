<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package varsity
 */
$opt = get_option('varsity_opt'); 
$if_footer_widget = isset( $opt['if_footer_widget'] ) ? $opt['if_footer_widget'] : '1';
$footer_social    = isset( $opt['footer_social_icon'] ) ? $opt['footer_social_icon'] : '1';
$copyright_txt    = isset( $opt['copyright_txt'] ) ? $opt['copyright_txt'] : '<p>Designed &amp; Developed by <a href="https://droitthemes.com/" target="_blank"> DroitThemes </a></p>';
$shape_images    = isset( $opt['footer_shape_images'] ) ? $opt['footer_shape_images'] : '1';
$shape_one       = isset( $opt['shape_one']['url'] ) ? $opt['shape_one']['url'] : VARSITY_DIR_IMG . '/icon/shape_01.png';
$shape_two       = isset( $opt['shape_two']['url'] ) ? $opt['shape_two']['url'] : VARSITY_DIR_IMG . '/icon/about_shape_02.png';
$shape_three     = isset( $opt['shape_three']['url'] ) ? $opt['shape_three']['url'] : VARSITY_DIR_IMG . '/icon/about_shape_03.png';
?>
<footer class="footer_section">
<div class="container">
    <div class="row justify-content-between">
        <?php if($if_footer_widget == '1'): ?>
        <?php dynamic_sidebar( 'footer_sidebar' ); ?>
        <?php endif; ?>
        <div class="col-lg-12">
            <div class="copyright_part">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-8">
                        <p style="text-align: center;"><?php echo wp_kses_post($copyright_txt); ?></p>
                    </div> 
                    <div class="col-lg-6 col-md-4">
                        <?php if($footer_social == '1'): ?>
                        <div class="social_icon">
                            <?php varsity_social_links(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if($shape_images == '1'): ?>
<img src="<?php echo esc_url($shape_one); ?>" alt="#" class="footer_sharp_1">
<img src="<?php echo esc_url($shape_two); ?>" alt="#" class="footer_sharp_2 custom-animation2">
<img src="<?php echo esc_url($shape_three); ?>" alt="#" class="footer_sharp_3 custom-animation3">
<?php endif; ?>
</footer>
<?php wp_footer(); ?>
</body>
</html>
