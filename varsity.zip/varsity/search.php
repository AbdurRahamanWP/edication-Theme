<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package varsity
 */
get_header();
?>
  <!-- corses details part -->
    <section class="blog_page section_padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="blog_post_list">
	                    <?php
	                      if ( have_posts() ) {
	                      while ( have_posts() ) :
	                      the_post();
	                    ?>
	                    <?php  get_template_part( 'template-parts/content', 'search' ); ?>
	                    <?php 
	                     endwhile;
	                     }
	                     else{
	                     get_template_part( 'template-parts/content', 'none' );
	                     }
	                    ?>
                    </div>
                    <div class="page_pageination justify-content-start">
                        <?php varsity_pagination(); ?>
                    </div>
                </div>
               <?php get_sidebar(); ?>
            </div>
        </div>
    </section>
    <!-- corses details part end -->	
<?php
get_footer();
