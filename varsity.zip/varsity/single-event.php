<?php
/**
 *  Template Name: Single Event
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package varsutt
 */
get_header();
?>
 <!-- breadcrumb part -->
    <section class="breadcrumb_part">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="breadcrumb_iner">
                        <h2><?php echo esc_html_e('Event Details','varsity') ?> </h2>
                         <div class="breadcrumb_iner_link">
                            <a href="<?php echo get_site_url(); ?>"><?php echo esc_html_e('Home','varsity') ?></a>
                            <a href="#"><?php echo esc_html_e('Event Details','varsity') ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb part end -->
    <!-- corses details part -->
    <section class="upcoming_event_details section_padding section_bg">
        <div class="container">
            <?php while ( have_posts() ) : the_post();
                $event_date      = function_exists( 'get_field' ) ? get_field( 'event_date' ) : '';
                $event_time      = function_exists( 'get_field' ) ? get_field( 'event_start_time' ) : '';
                $event_end_time  = function_exists( 'get_field' ) ? get_field( 'event_end_time' ) : '';
                $event_address   = function_exists( 'get_field' ) ? get_field( 'event_address' ) : '';
                $map             = function_exists( 'get_field' ) ? get_field( 'event_location' ) : '';
                $contact_number  = function_exists( 'get_field' ) ? get_field( 'contact_number' ) : '';
                $email_adress    = function_exists( 'get_field' ) ? get_field( 'email_adress' ) : '';
                $website_company = function_exists( 'get_field' ) ? get_field( 'website_company' ) : '';
            ?>  
            <div class="row">
                <div class="col-lg-9">
                    <div class="courses_details_iner">
                    <?php
                       if( has_post_thumbnail() ) : 
                       the_post_thumbnail( 'event_details_870_450', array( 'class' => 'img-fluid' ) );
                       endif;
                    ?>
                    </div>
                    <div class="upcoming_event_countdown">
                        <div id="clockdiv" class="eventcountdown" data-date="<?php echo esc_html($event_date); ?>">
                        </div>
                    </div>
                    <div class="upcoming_event_desc">
                        <p><i class="icon_calendar"></i><?php echo get_the_date(); ?></p>
                        <h2><?php the_title(); ?></h2>
                        <p><?php the_content(); ?></p>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="education_sidebar">
                        <div class="single_sidebar add_cart_sidebar">
                            <h4><?php echo esc_html_e('Event Details','varsity'); ?></h4>
                            <p><i class="icon_calendar"></i>
                                <?php echo esc_html_e('Date :','varsity') ?>
                                <?php echo esc_html($event_date); ?>
                            </p>
                            <p><i class="icon_clock_alt"></i>
                                <?php echo esc_html_e('Time:','varsity') ?>
                                <?php echo esc_html($event_time); ?> - <?php echo esc_html($event_end_time); ?>
                            </p>
                            <p><i class="icon_pin_alt"></i>
                                <?php echo esc_html_e('Address :','varsity') ?>
                                <?php echo esc_html($event_address); ?>
                            </p>
                        </div>
                        <div class="single_sidebar add_cart_sidebar">
                            <h4><?php echo esc_html_e('Content Us','varsity'); ?></h4>
                            <div class="contactMap">
                                <div id="contactMap" data-lat="<?php echo esc_html__($map['lat'],'varsity'); ?>" data-lon="<?php echo esc_html__($map['lng'],'varsity'); ?>" data-zoom="10"
                                 data-info="" 
                                 data-mlat="<?php echo esc_html__($map['lat'],'varsity'); ?>" data-mlon="<?php echo esc_html__($map['lng'],'varsity'); ?>">
                            </div>
                            </div>
                            <p><i class="icon_phone"></i><?php echo esc_html($contact_number); ?></p>
                            <p><i class="icon_mail_alt"></i><?php echo esc_html($email_adress); ?></p>
                            <p><i class="icon_globe-2"></i><?php echo esc_html($website_company); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
        </div>
    </section>
    <!-- instructor list part here -->
     <section class="instructor_list section_padding event_page_instructor">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h3> <?php echo  esc_html__( 'Event Instructor', 'varsity' ); ?></h3>
                    <div class="row">
                        <?php 
                        $instructor = new WP_Query(array(
                            'post_type'     => 'instructor',
                            'post_status' => 'publish',
                            'showposts' => 4 
                        ));
                         while ($instructor->have_posts()) : $instructor->the_post();
                               $department   = function_exists( 'get_field' ) ? get_field( 'instructor_department' ) : '';
                               $facebook_url = function_exists( 'get_field' ) ? get_field( 'facebook_url' ) : '';
                               $twitter_url  = function_exists( 'get_field' ) ? get_field( 'twitter_url' ) : '';
                               $linkedin_url = function_exists( 'get_field' ) ? get_field( 'linkedin_url' ) : '';
                        ?>
                        <div class="col-lg-3 col-sm-6 aos-init aos-animate" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="800">
                            <div class="single_instructor_item">
                                <div class="single_instructor">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                    <a href="<?php the_permalink(); ?>" class="instructor_img">
                                        <?php the_post_thumbnail( 'full', array( 'class' => 'img-fluid' ) ); ?>
                                    </a>
                                    <?php endif; ?>
                                    <div class="social_icon">
                                        <?php if(!empty($linkedin_url)): ?>
                                        <a href="<?php echo esc_url($linkedin_url); ?>"><i class="social_linkedin"></i></a>
                                        <?php endif; ?>
                                        <?php if(!empty($twitter_url)): ?>
                                        <a href="<?php echo esc_url($twitter_url); ?>"><i class="social_twitter"></i></a>
                                        <?php endif; ?>
                                        <?php if(!empty($facebook_url)): ?>
                                        <a href="<?php echo esc_url($facebook_url); ?>"><i class="social_facebook"></i></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="single_instructor_tittle">
                                    <h4> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    <p><?php echo esc_html($department); ?></p>
                                </div>
                            </div>
                        </div>
                         <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- instructor list part end -->
<?php
get_footer();