<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package varsity
 */

get_header();
$opt    = get_option('varsity_opt');
$blog_header_bg  = isset( $opt['blog_header_bg']['url'] ) ? $opt['blog_header_bg']['url'] : '';
$blog_title      = isset( $opt['blog_title'] ) ? $opt['blog_title']: esc_html__('Blog Classic' , 'varsity');
$is_blog_c2a     = isset( $opt['is_blog_c2a'] ) ? $opt['is_blog_c2a'] : '';
$c2t_title       = isset( $opt['c2t_title'] ) ? $opt['c2t_title']: esc_html__('Best teachers in every subject. <br>Let’s get started', 'varsity');
$c2t_sub_title   = isset( $opt['c2t_sub_title'] ) ? $opt['c2t_sub_title']: esc_html__('We can teach you anything', 'varsity');
$c2t_button_text = isset( $opt['c2t_button_text'] ) ? $opt['c2t_button_text']: esc_html__('Get Started', 'varsity');
$c2t_button_url  = isset( $opt['c2t_button_url'] ) ? $opt['c2t_button_url']: '';
?>
 <!-- breadcrumb part -->
    <section class="breadcrumb_part blog_grid_bg" <?php if(!empty($blog_header_bg)): ?> style="background-image: url('<?php echo esc_url($blog_header_bg); ?>')" <?php endif; ?>>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 ">
                    <div class="breadcrumb_iner">
                        <h2>
                        <?php
                          if(!empty($blog_title)){
                          echo esc_html($blog_title);
                          } else{
                            echo get_bloginfo('name');
                          }
                        ?>
                        </h2>
                        <?php varsity_breadcrumbs(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb part end -->
    <!-- corses details part -->
    <section class="blog_page section_padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="blog_post_list">
                    <?php
                      if ( have_posts() ) : 
                      while ( have_posts() ) :
                      the_post();
                    ?>
                    <?php  get_template_part( 'template-parts/content', get_post_type() ); ?>
                    <?php 
                    endwhile;
                    ?>
                    </div>
                    <div class="page_pageination justify-content-start">
                        <?php varsity_pagination(); ?>
                    </div>
                   <?php 
                     else :
                     get_template_part( 'template-parts/content', 'none' );
                     endif;
                    ?> 
                </div>
               <?php get_sidebar(); ?>
            </div>
        </div>
    </section>
    <!-- corses details part end -->
    <?php 
     if($is_blog_c2a == '1'):
    ?>
    <!-- cta part here -->
    <section class="cta_part section_padding">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="cta_part_iner">
                      <h2><?php echo wp_kses_post($c2t_title); ?></h2>
                      <p><?php echo wp_kses_post($c2t_sub_title); ?></p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="cta_btn">
                        <a href="<?php echo esc_url($c2t_button_url); ?>" class="btn_3"><?php echo esc_html($c2t_button_text); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="circle_shape_1"></div>
        <div class="circle_shape_2"></div>
    </section>
   <?php endif; ?> 
<?php
get_footer();